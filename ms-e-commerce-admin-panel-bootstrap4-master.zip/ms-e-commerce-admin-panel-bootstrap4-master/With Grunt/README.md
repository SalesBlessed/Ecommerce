MS E-Commerce Admin Panel
